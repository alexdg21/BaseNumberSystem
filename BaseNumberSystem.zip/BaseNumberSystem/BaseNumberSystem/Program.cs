﻿using System;

namespace BaseNumberSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter number to convert to base 8, enter X to exit:");
            convertToBaseEight();
        }
        static void convertToBaseEight()
        {
            while(true)
            {
                int userInputNumber = Int32.Parse(Console.ReadLine());
                if (userInputNumber == 0)
                {
                    break;
                }
                else if (userInputNumber < 0)
                {
                    Console.WriteLine("Invaild Input, try number greater than 0");
                }
                else
                {
                    string convertFinal = Convert.ToString(userInputNumber, 8);
                    Console.WriteLine("The base of 8 is " + convertFinal);
                }
            }
        }
    }
}
